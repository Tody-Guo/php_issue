-- phpMyAdmin SQL Dump
-- version 3.5.8.2
-- http://www.phpmyadmin.net
--
-- 主机: sql205.phpnet.us
-- 生成日期: 2014 年 11 月 25 日 04:34
-- 服务器版本: 5.6.21-70.0
-- PHP 版本: 5.3.3

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- 数据库: `pn_15584718_eng`
--

-- --------------------------------------------------------

--
-- 表的结构 `validate_issues`
--

CREATE TABLE IF NOT EXISTS `validate_issues` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `val_reason` varchar(1024) NOT NULL,
  `val_purpose` varchar(1024) NOT NULL,
  `val_scheme` varchar(1024) NOT NULL,
  `val_failrate` varchar(1024) NOT NULL,
  `val_content` text NOT NULL,
  `val_owner` varchar(1024) NOT NULL,
  `val_date` datetime NOT NULL,
  `val_status` varchar(1024) NOT NULL,
  `reserved1` varchar(30) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- 转存表中的数据 `validate_issues`
--

INSERT INTO `validate_issues` (`id`, `val_reason`, `val_purpose`, `val_scheme`, `val_failrate`, `val_content`, `val_owner`, `val_date`, `val_status`, `reserved1`) VALUES
(3, 'CASPER LCD休眠唤醒白屏', 'FAE通知客户', 'BIOS FIX', '几率性不良：2/50', '&lt;p&gt;1，OBA测试发现休眠唤醒LCD白屏&lt;/p&gt;&lt;p&gt;2，不良率在2/50左右&lt;/p&gt;&lt;p&gt;3，初步怀疑：PVO 屏的问题或LVDS排线问题&lt;/p&gt;&lt;p&gt;4，待11月25日FAE通客户确认，如果客户不同意则要进行Rework。&lt;/p&gt;&lt;p&gt;5，已提供不良视频给客户确认。&lt;br /&gt;&lt;/p&gt;', 'EE', '2014-11-24 20:40:58', 'Open', '2014-11-25 16:59:11'),
(4, 'Acer 平板FIVT测试结果Fail', '反馈给Acer', 'Acer专门出一版给平板使用的FIVT脚本', '100%', '&lt;p&gt;Acer 平板FIVT测试结果Fail&lt;/p&gt;&lt;p&gt;目前不良LOG已经反馈给Acer确认是否为G-sensor的Driver问题所致。&lt;/p&gt;&lt;p&gt;目前Acer Ajax确认g-sensor在OOBE阶段有可能被系统禁掉，导致CHECKLOGO8测试项目FAIL，经过移除CHECKLOGO8项目后，&lt;span style=&quot;color:#009900;&quot;&gt;FIVT测试结果PASS&lt;/span&gt;&lt;/p&gt;&lt;p&gt;&lt;span style=&quot;color:#009900;&quot;&gt;&lt;span style=&quot;color:#000000;&quot;&gt;1，Acer提供新版PATCH CD供测试，预计11月26日有测试结果。&lt;/span&gt;&lt;br /&gt;&lt;/span&gt;&lt;/p&gt;', '郭加辉', '2014-11-25 11:54:17', 'Tracking', '2014-11-25 17:10:01'),
(5, 'Acer WiFi RSSI &amp; Though-put testing', '购买RF设备', '导入生产线测试', '100%', '&lt;p&gt;1，目前衰减器(Attenuator)目前已经拿到&lt;/p&gt;&lt;p&gt;2，Cisco AP已经请购，待收货，预计11月28日OK。&lt;/p&gt;&lt;p&gt;3，屏蔽箱（R&amp;amp;S）目前正在与小波确认是否可在11/E完成。&lt;/p&gt;&lt;p&gt;4，联系了安吉伦的仪器厂商，厂商确认能提供仪器给我们使用的日期，预计11月26日有结果。&lt;br /&gt;&lt;/p&gt;', '郭加辉', '2014-11-25 13:26:51', 'Open', '2014-11-25 17:16:33'),
(6, 'Intel CMPC FUSE test', 'RD提供FUSE.txt文件', '导入CMPC 200PCS测试', '100%', '1，RD目前正在确认FUSE.TXT的文件，待提供OK后借IRT机器验证。', '郭加辉', '2014-11-25 13:28:31', 'Open', '');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
